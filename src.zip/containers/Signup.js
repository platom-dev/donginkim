import React from 'react';

const Signup = () => (
    <div>
        Signup
    </div>
);

export default Signup;