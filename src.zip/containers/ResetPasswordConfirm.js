import React from 'react';

const ResetPasswordConfirm = () => (
    <div>
        ResetPasswordConfirm
    </div>
);

export default ResetPasswordConfirm;